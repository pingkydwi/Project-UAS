package com.example.verobank

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
