import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:verobank/models/user.dart';
import 'package:verobank/models/transaction.dart';
import 'package:verobank/providers/auth_provider.dart';
import 'package:verobank/providers/transaction_provider.dart';
import 'package:verobank/screens/login_screen.dart';
import 'package:verobank/screens/register_screen.dart';
import 'package:verobank/screens/home_screen.dart';
import 'package:verobank/screens/transfer_screen.dart';
import 'package:verobank/screens/ewallet_screen.dart';
import 'package:verobank/screens/history_screen.dart';
import 'package:verobank/screens/transaction_detail_screen.dart';
import 'package:verobank/screens/account_profile_screen.dart';
import 'package:verobank/screens/account_details_screen.dart';
import 'package:verobank/screens/account_password_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Hive.initFlutter();
    Hive.registerAdapter(UserAdapter());
    Hive.registerAdapter(TransactionAdapter());
    await Hive.openBox<User>('users');
    await Hive.openBox<Transaction>('transactions');
    print('Hive initialized and boxes opened successfully');
  } catch (e) {
    print('Hive initialization error: $e');
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => TransactionProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VeroBank',
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF00E5FF),
        scaffoldBackgroundColor: const Color(0xFF0D0D1A),
      ),
      initialRoute: '/splash',
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/home': (context) => const HomeScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/account': (context) => const AccountProfileScreen(),
        '/account_details': (context) => const AccountDetailsScreen(),
        '/account_password': (context) => const AccountPasswordScreen(),
        '/transfer': (context) => const TransferScreen(),
        '/topup': (context) => const EWalletScreen(),
        '/history': (context) => const HistoryScreen(),
        '/transaction_detail': (context) => const TransactionDetailScreen(),
      },
    );
  }
}

class SkyGradientBackground extends StatelessWidget {
  final Widget child;

  const SkyGradientBackground({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1A1A2E), Color(0xFF0D0D1A)],
        ),
      ),
      child: child,
    );
  }
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SkyGradientBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Pengaturan',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
                ListTile(
                  leading: const Icon(Icons.person, color: Color(0xFF00E5FF)),
                  title: const Text('Pusat Akun', style: TextStyle(color: Colors.white)),
                  onTap: () => Navigator.pushNamed(context, '/account'),
                ),
                ListTile(
                  leading: const Icon(Icons.lock, color: Color(0xFF00E5FF)),
                  title: const Text('Ubah Password', style: TextStyle(color: Colors.white)),
                  onTap: () => Navigator.pushNamed(context, '/account_password'),
                ),
                ListTile(
                  leading: const Icon(Icons.info, color: Color(0xFF00E5FF)),
                  title: const Text('Detail Akun', style: TextStyle(color: Colors.white)),
                  onTap: () => Navigator.pushNamed(context, '/account_details'),
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: Color(0xFF00E5FF)),
                  title: const Text('Keluar', style: TextStyle(color: Colors.white)),
                  onTap: () {
                    Provider.of<AuthProvider>(context, listen: false).logout();
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacementNamed(context, '/login');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SkyGradientBackground(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 50,
                backgroundColor: Color(0xFF00E5FF),
                child: Icon(
                  Icons.account_balance,
                  size: 60,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'VeroBank',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(2, 2),
                        ),
                      ],
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}