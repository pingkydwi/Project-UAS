import 'package:hive/hive.dart';

part 'user.g.dart';

@HiveType(typeId: 0)
class User extends HiveObject {
  @HiveField(0)
  String? username;

  @HiveField(1)
  String? password;

  @HiveField(2)
  double balance = 0.0;

  @HiveField(3)
  String? fullName;

  @HiveField(4)
  String? profileImagePath;

  User({this.username, this.password, this.balance = 0.0, this.fullName, this.profileImagePath});
}