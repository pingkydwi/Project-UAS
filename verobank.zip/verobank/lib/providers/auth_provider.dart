import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:verobank/models/user.dart';

class AuthProvider with ChangeNotifier {
  Box<User> _userBox = Hive.box<User>('users');
  bool _isAuthenticated = false;
  double _balance = 1000000000.0; // Ubah saldo awal menjadi 1.000.000.000
  String? _username;

  bool get isAuthenticated => _isAuthenticated;
  double get balance => _balance;
  String? get username => _username;

  User? get currentUser {
    if (_isAuthenticated && _username != null && _userBox.isNotEmpty) {
      return _userBox.values.firstWhere(
        (user) => user.username == _username,
        orElse: () => User(username: '', password: '', balance: 0.0, fullName: ''),
      );
    }
    return null;
  }

  AuthProvider() {
    if (_userBox.isNotEmpty) {
      final user = _userBox.values.first;
      _isAuthenticated = true;
      _username = user.username;
      _balance = user.balance;
      print('Inisialisasi AuthProvider - Username: $_username, Saldo: $_balance');
    }
  }

  Future<bool> login(String username, String password) async {
    try {
      final user = _userBox.values.firstWhere(
        (user) => user.username == username && user.password == password,
        orElse: () => User(username: '', password: '', balance: 0.0, fullName: ''),
      );

      if (user.username?.isNotEmpty ?? false) {
        _isAuthenticated = true;
        _username = username;
        _balance = user.balance;
        print('Login berhasil - Username: $_username, Saldo: $_balance');
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      print('Login error: $e');
      return false;
    }
  }

  Future<bool> register(String username, String password, {String fullName = ''}) async {
    try {
      final existingUser = _userBox.values.firstWhere(
        (user) => user.username == username,
        orElse: () => User(username: '', password: '', balance: 0.0, fullName: ''),
      );

      if (existingUser.username?.isNotEmpty ?? false) {
        return false;
      }

      final newUser = User(
        username: username,
        password: password,
        balance: 1000000000.0, // Ubah saldo awal pengguna baru menjadi 1.000.000.000
        fullName: fullName,
      );
      await _userBox.add(newUser);
      print('Registrasi berhasil - Username: $username, Saldo awal: 1000000000.0');
      return true;
    } catch (e) {
      print('Register error: $e');
      return false;
    }
  }

  void updateBalance(double amount) {
    print('Sebelum update - Saldo: $_balance, Perubahan: $amount');
    _balance += amount;
    print('Setelah update - Saldo: $_balance');

    if (_isAuthenticated && _username != null && _userBox.isNotEmpty) {
      final user = _userBox.values.firstWhere(
        (u) => u.username == _username,
        orElse: () => User(username: '', password: '', balance: 0.0, fullName: ''),
      );
      if (user.username?.isNotEmpty ?? false) {
        user.balance = _balance;
        user.save();
        print('Saldo disimpan di Hive: ${user.balance}');
      }
    }
    notifyListeners();
  }

  void logout() {
    _isAuthenticated = false;
    _username = null;
    _balance = 1000000000.0; // Reset saldo ke 1.000.000.000 saat logout
    print('Logout - Saldo direset ke: $_balance');
    notifyListeners();
  }
}