import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:verobank/models/transaction.dart';
import 'package:provider/provider.dart';
import 'package:verobank/providers/auth_provider.dart';

class TransactionProvider with ChangeNotifier {
  Box<Transaction> _transactionsBox = Hive.box<Transaction>('transactions');
  List<Transaction> get transactions => _transactionsBox.values.toList();

  void addTransaction(String transactionType, double amount, String description, BuildContext context, {double? amountEffect}) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    // Cek saldo cukup untuk transaksi yang mengurangi saldo
    if ((transactionType == 'Transfer' || transactionType.startsWith('EWalletExternal')) && authProvider.balance < amount) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Saldo tidak cukup',
            style: TextStyle(color: Colors.white),
          ),
        ),
      );
      return;
    }

    // Tambahkan transaksi ke Hive
    final transaction = Transaction(
      transactionType: transactionType,
      amount: amount,
      description: description,
      date: DateTime.now(),
    );
    _transactionsBox.add(transaction);
    print('Transaksi ditambahkan - Tipe: $transactionType, Jumlah: $amount, Deskripsi: $description');

    // Kelola saldo berdasarkan tipe transaksi
    if (transactionType == 'Transfer') {
      authProvider.updateBalance(-amount); // Kurangi saldo untuk Transfer
    } else if (transactionType.startsWith('EWalletExternal')) {
      authProvider.updateBalance(-amount); // Kurangi saldo untuk semua EWalletExternal (DANA, ShopeePay, dll.)
    } else if (transactionType == 'EWalletInternal') {
      authProvider.updateBalance(amount); // Tambah saldo untuk EWalletInternal (penerimaan)
    }

    notifyListeners();
  }

  void deleteTransaction(int id) {
    _transactionsBox.deleteAt(id);
    print('Transaksi dihapus - ID: $id');
    notifyListeners();
  }
}