import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:verobank/providers/auth_provider.dart';
import 'package:verobank/providers/transaction_provider.dart';
import 'package:flutter/animation.dart';
import '../main.dart';

class EWalletScreen extends StatefulWidget {
  const EWalletScreen({Key? key}) : super(key: key);

  @override
  _EWalletScreenState createState() => _EWalletScreenState();
}

class _EWalletScreenState extends State<EWalletScreen> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  String _recipient = '';
  String _phoneNumber = '';
  double _amount = 0.0;
  String _description = '';
  String _selectedEWallet = 'DANA';
  final List<String> _eWalletOptions = ['DANA', 'ShopeePay', 'GoPay', 'OVO', 'LinkAja'];

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation1;
  late Animation<Offset> _slideAnimation2;
  late Animation<Offset> _slideAnimation3;
  late Animation<Offset> _slideAnimation4;
  late Animation<Offset> _slideAnimation5;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);

    // Animasi slide untuk setiap field
    _slideAnimation1 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.4, curve: Curves.easeOut)),
    );
    _slideAnimation2 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.1, 0.5, curve: Curves.easeOut)),
    );
    _slideAnimation3 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.2, 0.6, curve: Curves.easeOut)),
    );
    _slideAnimation4 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.3, 0.7, curve: Curves.easeOut)),
    );
    _slideAnimation5 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.4, 0.8, curve: Curves.easeOut)),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _processTransaction() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final transactionProvider = Provider.of<TransactionProvider>(context, listen: false);

      String transactionType = 'EWalletExternal_$_selectedEWallet';
      String fullDescription = 'Pengeluaran ke $_recipient (Nomor: $_phoneNumber): $_description';

      transactionProvider.addTransaction(
        transactionType,
        _amount,
        fullDescription,
        context,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Transaksi e-wallet berhasil',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0D1B2A), Color(0xFF1B263B)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          border: Border.all(
            color: const Color(0xFF00E5FF).withOpacity(0.2),
            width: 2,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'E-Wallet',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(
                                  color: const Color(0xFF00E5FF).withOpacity(0.5),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  Expanded(
                    child: Card(
                      elevation: 15,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                      color: Colors.transparent,
                      child: Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF1E1E2F), Color(0xFF2A2A3F)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(
                            color: const Color(0xFF00E5FF).withOpacity(0.3),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00E5FF).withOpacity(0.2),
                              blurRadius: 20,
                              spreadRadius: 5,
                              offset: const Offset(0, 5),
                            ),
                            BoxShadow(
                              color: const Color(0xFF8B5CF6).withOpacity(0.1),
                              blurRadius: 15,
                              spreadRadius: 3,
                              offset: const Offset(0, -3),
                            ),
                          ],
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Dropdown E-Wallet
                              SlideTransition(
                                position: _slideAnimation1,
                                child: DropdownButtonFormField<String>(
                                  value: _selectedEWallet,
                                  decoration: InputDecoration(
                                    labelText: 'E-Wallet Tujuan',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.account_balance_wallet,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  dropdownColor: const Color(0xFF2A2A3F),
                                  icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF00E5FF)),
                                  items: _eWalletOptions.map((String eWallet) {
                                    return DropdownMenuItem<String>(
                                      value: eWallet,
                                      child: Text(eWallet, style: const TextStyle(color: Colors.white)),
                                    );
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      _selectedEWallet = newValue!;
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Nama Penerima
                              SlideTransition(
                                position: _slideAnimation2,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Penerima',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.person,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  validator: (value) =>
                                      value!.isEmpty ? 'Penerima tidak boleh kosong' : null,
                                  onSaved: (value) => _recipient = value!,
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Nomor Telepon
                              SlideTransition(
                                position: _slideAnimation3,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Nomor Telepon',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.phone,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.phone,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Nomor telepon tidak boleh kosong';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) => _phoneNumber = value!,
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Jumlah
                              SlideTransition(
                                position: _slideAnimation4,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Jumlah',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.money,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.number,
                                  validator: (value) {
                                    if (value!.isEmpty) return 'Jumlah tidak boleh kosong';
                                    final amount = double.tryParse(value);
                                    if (amount == null || amount <= 0) {
                                      return 'Jumlah harus lebih dari 0';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) => _amount = double.parse(value!),
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Deskripsi
                              SlideTransition(
                                position: _slideAnimation5,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Deskripsi (opsional)',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.description,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  onSaved: (value) => _description = value ?? '',
                                ),
                              ),
                              const SizedBox(height: 30),
                              // Tombol Kirim dengan efek animasi
                              SlideTransition(
                                position: _slideAnimation5,
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  child: ElevatedButton(
                                    onPressed: _processTransaction,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF8B5CF6),
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 18),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      elevation: 10,
                                      shadowColor: const Color(0xFF8B5CF6).withOpacity(0.5),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: const [
                                        Icon(Icons.send, color: Colors.white),
                                        SizedBox(width: 10),
                                        Text(
                                          'Kirim',
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}