import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:verobank/providers/transaction_provider.dart';
import 'package:flutter/animation.dart';
import '../main.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final transactionProvider = Provider.of<TransactionProvider>(context);
    final transactions = transactionProvider.transactions
      ..sort((a, b) => b.date.compareTo(a.date));

    return Scaffold(
      body: SkyGradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Riwayat Transaksi',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  Expanded(
                    child: transactions.isEmpty
                        ? const Center(
                            child: Text(
                              'Belum ada transaksi',
                              style: TextStyle(color: Colors.white70),
                            ),
                          )
                        : ListView.builder(
                            itemCount: transactions.length,
                            itemBuilder: (context, index) {
                              final tx = transactions[index];
                              return Dismissible(
                                key: Key(tx.key.toString()),
                                background: Container(
                                  color: Colors.redAccent,
                                  alignment: Alignment.centerRight,
                                  padding: const EdgeInsets.only(right: 20),
                                  child: const Icon(Icons.delete, color: Colors.white),
                                ),
                                direction: DismissDirection.endToStart,
                                onDismissed: (direction) {
                                  transactionProvider.deleteTransaction(index);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        '${tx.transactionType} dihapus',
                                        style: const TextStyle(color: Colors.white),
                                      ),
                                    ),
                                  );
                                },
                                child: Card(
                                  margin: const EdgeInsets.symmetric(vertical: 8),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  color: const Color(0xFF1E1E2F).withOpacity(0.8),
                                  child: ListTile(
                                    leading: Icon(
                                      tx.transactionType == 'Transfer'
                                          ? Icons.arrow_upward
                                          : Icons.arrow_downward,
                                      color: tx.transactionType == 'Transfer'
                                          ? Colors.redAccent
                                          : Colors.greenAccent,
                                    ),
                                    title: Text(
                                      tx.transactionType,
                                      style: const TextStyle(color: Colors.white),
                                    ),
                                    subtitle: Text(
                                      tx.date.toString(),
                                      style: const TextStyle(color: Colors.white70),
                                    ),
                                    trailing: Text(
                                      'Rp ${tx.amount.toStringAsFixed(2)}',
                                      style: TextStyle(
                                        color: tx.transactionType == 'Transfer'
                                            ? Colors.redAccent
                                            : Colors.greenAccent,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    onTap: () {
                                      Navigator.pushNamed(
                                        context,
                                        '/transaction_detail',
                                        arguments: tx,
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}