import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:verobank/providers/auth_provider.dart';
import 'package:verobank/providers/transaction_provider.dart';
import 'package:verobank/screens/ewallet_screen.dart';
import 'package:verobank/screens/transfer_screen.dart';
import 'package:intl/intl.dart';
import '../main.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final transactionProvider = Provider.of<TransactionProvider>(context);

    // Format saldo dengan pemisah ribuan
    final NumberFormat currencyFormat = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 2);

    return Scaffold(
      body: SkyGradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header Section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: const Color(0xFF00E5FF).withOpacity(0.2),
                              child: const Icon(
                                Icons.person,
                                color: Color(0xFF00E5FF),
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Selamat Datang',
                                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        shadows: [
                                          Shadow(
                                            color: Colors.black.withOpacity(0.3),
                                            blurRadius: 4,
                                            offset: const Offset(1, 1),
                                          ),
                                        ],
                                      ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  authProvider.username ?? 'Pengguna',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                        color: Colors.white70,
                                        fontWeight: FontWeight.w500,
                                      ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.settings, color: Colors.white, size: 30),
                          onPressed: () => Navigator.pushNamed(context, '/settings'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),

                    // Balance Card
                    ScaleTransition(
                      scale: _scaleAnimation,
                      child: Card(
                        elevation: 12,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: const BorderSide(
                            color: Color(0xFF00E5FF),
                            width: 1.5,
                          ),
                        ),
                        color: const Color(0xFF1E1E2F).withOpacity(0.95),
                        child: Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF00E5FF), Color(0xFF0066FF)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF00E5FF).withOpacity(0.4),
                                blurRadius: 15,
                                spreadRadius: 5,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Saldo Anda',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    currencyFormat.format(authProvider.balance),
                                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                ],
                              ),
                              const Icon(
                                Icons.account_balance_wallet,
                                color: Colors.white70,
                                size: 40,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Action Buttons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildActionButton(
                          context,
                          label: 'E Wallet',
                          icon: Icons.account_balance_wallet,
                          onTap: () => Navigator.pushNamed(context, '/topup'),
                        ),
                        _buildActionButton(
                          context,
                          label: 'Transfer',
                          icon: Icons.send,
                          onTap: () => Navigator.pushNamed(context, '/transfer'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    // Transaction History
                    Card(
                      elevation: 8,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: const Color(0xFF1E1E2F).withOpacity(0.95),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Riwayat Transaksi Terbaru',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                                if (transactionProvider.transactions.isNotEmpty)
                                  TextButton(
                                    onPressed: () => Navigator.pushNamed(context, '/history'),
                                    child: const Text(
                                      'Lihat Semua',
                                      style: TextStyle(color: Color(0xFF00E5FF)),
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            SizedBox(
                              height: 200,
                              child: transactionProvider.transactions.isEmpty
                                  ? const Center(
                                      child: Text(
                                        'Belum ada transaksi',
                                        style: TextStyle(color: Colors.white54),
                                      ),
                                    )
                                  : ListView.separated(
                                      itemCount: transactionProvider.transactions.length > 5
                                          ? 5
                                          : transactionProvider.transactions.length,
                                      separatorBuilder: (context, index) => const Divider(
                                        color: Colors.white12,
                                        height: 1,
                                      ),
                                      itemBuilder: (context, index) {
                                        final transaction =
                                            transactionProvider.transactions.reversed.toList()[index];
                                        return ListTile(
                                          leading: Icon(
                                            transaction.amount >= 0
                                                ? Icons.arrow_downward
                                                : Icons.arrow_upward,
                                            color: transaction.amount >= 0 ? Colors.green : Colors.red,
                                            size: 24,
                                          ),
                                          title: Text(
                                            transaction.description,
                                            style: const TextStyle(color: Colors.white70, fontSize: 14),
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          subtitle: Text(
                                            'Tanggal: ${transaction.date.toLocal().toString().split(' ')[0]}',
                                            style: const TextStyle(color: Colors.white54, fontSize: 12),
                                          ),
                                          trailing: Text(
                                            'Rp ${transaction.amount.toStringAsFixed(2)}',
                                            style: TextStyle(
                                              color: transaction.amount >= 0 ? Colors.green : Colors.red,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 14,
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(BuildContext context, {required String label, required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          width: 140,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF00E5FF), Color(0xFF0066FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00E5FF).withOpacity(0.3),
                blurRadius: 8,
                spreadRadius: 2,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 24),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}