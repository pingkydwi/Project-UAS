import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:verobank/providers/auth_provider.dart';
import 'package:verobank/providers/transaction_provider.dart';
import 'package:flutter/animation.dart';
import '../main.dart';

class TransferScreen extends StatefulWidget {
  const TransferScreen({Key? key}) : super(key: key);

  @override
  _TransferScreenState createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  String _recipient = '';
  String _accountNumber = '';
  double _amount = 0.0;
  String _description = '';
  String _selectedBank = 'BRI';
  final List<String> _bankOptions = ['BRI', 'BNI', 'Mandiri', 'BCA', 'CIMB Niaga'];

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation1;
  late Animation<Offset> _slideAnimation2;
  late Animation<Offset> _slideAnimation3;
  late Animation<Offset> _slideAnimation4;
  late Animation<Offset> _slideAnimation5;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);

    // Animasi slide untuk setiap field
    _slideAnimation1 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.0, 0.4, curve: Curves.easeOut)),
    );
    _slideAnimation2 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.1, 0.5, curve: Curves.easeOut)),
    );
    _slideAnimation3 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.2, 0.6, curve: Curves.easeOut)),
    );
    _slideAnimation4 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.3, 0.7, curve: Curves.easeOut)),
    );
    _slideAnimation5 = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.4, 0.8, curve: Curves.easeOut)),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _transfer() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final transactionProvider = Provider.of<TransactionProvider>(context, listen: false);

      String fullDescription = 'Transfer ke $_recipient (Bank: $_selectedBank, No. Rek: $_accountNumber): $_description';
      transactionProvider.addTransaction(
        'Transfer',
        _amount,
        fullDescription,
        context,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Transfer berhasil',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0D1B2A), Color(0xFF1B263B)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Transfer',
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(
                                  color: const Color(0xFF00E5FF).withOpacity(0.5),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white, size: 30),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  Expanded(
                    child: Card(
                      elevation: 15,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                      color: Colors.transparent,
                      child: Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF1E1E2F), Color(0xFF2A2A3F)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(25),
                          border: Border.all(
                            color: const Color(0xFF00E5FF).withOpacity(0.3),
                            width: 1.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF00E5FF).withOpacity(0.2),
                              blurRadius: 20,
                              spreadRadius: 5,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // Dropdown Bank
                              SlideTransition(
                                position: _slideAnimation1,
                                child: DropdownButtonFormField<String>(
                                  value: _selectedBank,
                                  decoration: InputDecoration(
                                    labelText: 'Bank Tujuan',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.account_balance,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  dropdownColor: const Color(0xFF2A2A3F),
                                  icon: const Icon(Icons.arrow_drop_down, color: Color(0xFF00E5FF)),
                                  items: _bankOptions.map((String bank) {
                                    return DropdownMenuItem<String>(
                                      value: bank,
                                      child: Text(bank, style: const TextStyle(color: Colors.white)),
                                    );
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      _selectedBank = newValue!;
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Nama Penerima
                              SlideTransition(
                                position: _slideAnimation2,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Penerima',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.person,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  validator: (value) =>
                                      value!.isEmpty ? 'Penerima tidak boleh kosong' : null,
                                  onSaved: (value) => _recipient = value!,
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Nomor Rekening
                              SlideTransition(
                                position: _slideAnimation3,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Nomor Rekening',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.account_balance_wallet,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.number,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Nomor rekening tidak boleh kosong';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) => _accountNumber = value!,
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Jumlah
                              SlideTransition(
                                position: _slideAnimation4,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Jumlah',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.money,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  keyboardType: TextInputType.number,
                                  validator: (value) {
                                    if (value!.isEmpty) return 'Jumlah tidak boleh kosong';
                                    final amount = double.tryParse(value);
                                    if (amount == null || amount <= 0) {
                                      return 'Jumlah harus lebih dari 0';
                                    }
                                    return null;
                                  },
                                  onSaved: (value) => _amount = double.parse(value!),
                                ),
                              ),
                              const SizedBox(height: 20),
                              // Deskripsi
                              SlideTransition(
                                position: _slideAnimation5,
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    labelText: 'Deskripsi (opsional)',
                                    labelStyle: const TextStyle(color: Color(0xFF00E5FF)),
                                    filled: true,
                                    fillColor: Colors.white.withOpacity(0.1),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide.none,
                                    ),
                                    prefixIcon: const Icon(
                                      Icons.description,
                                      color: Color(0xFF00E5FF),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: BorderSide(
                                        color: const Color(0xFF00E5FF).withOpacity(0.3),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15),
                                      borderSide: const BorderSide(
                                        color: Color(0xFF00E5FF),
                                        width: 2,
                                      ),
                                    ),
                                  ),
                                  style: const TextStyle(color: Colors.white),
                                  onSaved: (value) => _description = value ?? '',
                                ),
                              ),
                              const SizedBox(height: 30),
                              // Tombol Transfer dengan efek animasi
                              SlideTransition(
                                position: _slideAnimation5,
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 300),
                                  child: ElevatedButton(
                                    onPressed: _transfer,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF00E5FF),
                                      foregroundColor: Colors.black87,
                                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 18),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      elevation: 10,
                                      shadowColor: const Color(0xFF00E5FF).withOpacity(0.5),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: const [
                                        Icon(Icons.send, color: Colors.white),
                                        SizedBox(width: 10),
                                        Text(
                                          'Transfer',
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}